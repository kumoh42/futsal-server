import { Column, Entity, PrimaryGeneratedColumn } from 'typeorm';

@Entity('xe_reservation')
export class Xe_ReservationEntity {
  /**
   * xe_reservation - reservation_srl
   * @description xe_member pk 입니다.
   *
   * PK, NN, AI
   */
  @PrimaryGeneratedColumn()
  reservation_srl: number;

  /**
   * xe_reservation - member_id
   * @description 예약자. xe_member 테이블의 member_srl 값입니다. 그러나 fk는 아닙니다.
   *
   * Default - NULL
   */
  @Column()
  member_id: number;

  /**
   * xe_reservation - place_srl
   * @description 예약한 장소를 의미합니다. 현재 풋살장 밖에 사용하지 않으므로 전부 0으로 처리됩니다.
   *
   * Default - NULL
   */
  @Column()
  place_srl: number;

  /**
   * xe_reservation - circle
   * @description 예약자 동아리를 의미합니다. 한글 문자열으로 입력되어 있습니다.
   */
  @Column({ length: 20 })
  circle: string;

  /**
   * xe_reservation - circle
   * @description 예약자가 속한 학과를 의미합니다. 한글 문자열으로 입력되어 있습니다.
   *
   * Default - NULL
   */
  @Column({ length: 10 })
  major: string;

  /**
   * xe_reservation - date
   * @description 사용날짜를 의미합니다.
   *
   * NN
   */
  @Column({ length: 11 })
  date: string;

  @Column()
  /**
   * xe_reservation - time
   * @description 사용 시간을 의미합니다.
   *
   * NN
   */
  time: number;

  /**
   * xe_reservation - is_able
   * @description  ???
   *
   * NN
   *
   * Default - 'N'
   */
  @Column({ length: 1 })
  is_able: string;

  /**
   * xe_reservation - is_holyday
   * @description 예약날의 주말 여부를 의미합니다.
   *
   * NN
   *
   * Default - 'N'
   */
  @Column({ length: 1 })
  is_holyday: string;

  /**
   * xe_reservation - regdate
   * @description ???2
   *
   * NN
   *
   * Default - CURRENT_TIMESTAMP() ON UPDATE CURRENT_TIMESTAMP()
   */
  @Column({ length: 40 })
  regdatge: string;
}
